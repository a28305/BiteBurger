async function obtenerTodosLosProductos() {
    const url = "http://localhost:8080/Proyecto/Controller?ACTION=PRODUCTO.FIND_ALL";
  
    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error(`Error HTTP: ${response.status}`);
      const productos = await response.json();
      return productos;
    } catch (error) {
      console.error("Error al obtener productos:", error);
      return [];
    }
}

async function filterProductsByCategory(filter) {

    if (filter === "Reload") {
      
    }
}

async function hamburguesarandom(){
    try {
      const res = await fetch(`${BASE_URL}?ACTION=PRODUCTO.FIND_BY_CATEGORY&id_categoria=${1}`);
      if (!res.ok) throw new Error("Error en la respuesta de la API");
      const productos = await res.json();

        const copia = [...productos];
        const seleccionados = [];
      
        const max = Math.min(cantidad, copia.length);
        for (let i = 0; i < max; i++) {
          const index = Math.floor(Math.random() * copia.length);
          seleccionados.push(copia[index]);
          copia.splice(index, 1); 
        }
        renderProducts(seleccionados);   
        return seleccionados;
    } catch (err) {
      console.error("Error fetching products by category:", err);
      renderProducts([]);
    }
}

async function bebidarandom(){
    try {
      const res = await fetch(`${BASE_URL}?ACTION=PRODUCTO.FIND_BY_CATEGORY&id_categoria=${6}`);
      if (!res.ok) throw new Error("Error en la respuesta de la API");
      const productos = await res.json();
      const copia = [...productos];
      const seleccionados = [];
      const max = Math.min(cantidad, copia.length);
        for (let i = 0; i < max; i++) {
          const index = Math.floor(Math.random() * copia.length);
          seleccionados.push(copia[index]);
          copia.splice(index, 1); 
        }
        renderProducts(seleccionados);   
        return seleccionados;
    } catch (err) {
      console.error("Error fetching products by category:", err);
      renderProducts([]);
    }
}

async function veganarandom(){
    try {
      const res = await fetch(`${BASE_URL}?ACTION=PRODUCTO.FIND_BY_CATEGORY&id_categoria=${2}`);
      if (!res.ok) throw new Error("Error en la respuesta de la API");
      const productos = await res.json();

        const copia = [...productos];
        const seleccionados = [];
      
        const max = Math.min(cantidad, copia.length);
        for (let i = 0; i < max; i++) {
          const index = Math.floor(Math.random() * copia.length);
          seleccionados.push(copia[index]);
          copia.splice(index, 1); 
        }
        renderProducts(seleccionados);   
        return seleccionados;
    } catch (err) {
      console.error("Error fetching products by category:", err);
      renderProducts([]);
    }
}

async function mostrarmenudia() {
    const productos = await obtenerTodosLosProductos();

    if (productos.length === 0) {
      document.getElementById("productos-container").innerText = "No hay productos disponibles.";
      return;
    }
  
    const hamburguesa  = hamburguesarandom(productos, 1);
    const bebida  = bebidarandom(productos, 1);
    const veggana = veganarandom (productos, 1)
    renderizarProductos(hamburguesa);
    renderizarProductos(bebida);
    renderizarProductos(veggana);
}


  
  
  

  
  